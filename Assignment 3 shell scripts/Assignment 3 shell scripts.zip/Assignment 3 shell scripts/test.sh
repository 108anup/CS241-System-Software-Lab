#!/bin/bash


## CASE STATEMENT EXAMPLE
# read x
# case $x in
# 	"\*") echo "x is star";
# 	;;
# 	"+") echo "x is plus";
# 	;;
# 	"*") echo "x is star 2";
# 	;;
# esac